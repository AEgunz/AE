// Main JavaScript for PUBG Mobile Tournament Website

document.addEventListener('DOMContentLoaded', function() {
    // Fetch site configuration (including donation and YouTube links)
    fetchSiteConfig();
    
    // Fetch upcoming matches
    fetchUpcomingMatches();
    
    // Fetch live matches
    fetchLiveMatches();
    
    // Fetch all teams
    fetchTeams();
    
    // Fetch rankings
    fetchRankings();
    
    // Handle team registration form submission
    const registrationForm = document.getElementById('team-registration-form');
    if (registrationForm) {
        registrationForm.addEventListener('submit', handleTeamRegistration);
    }
});

// Fetch site configuration
function fetchSiteConfig() {
    fetch('/api/config/')
        .then(response => response.json())
        .then(data => {
            // Set donation link
            const donationLinks = document.querySelectorAll('#donation-link, #donation-footer-link');
            donationLinks.forEach(link => {
                link.href = data.donation_link || 'https://streamlabs.com/aegaming91/tip';
            });
            
            // Set YouTube channel link
            const youtubeLinks = document.querySelectorAll('#youtube-link, #youtube-footer-link');
            youtubeLinks.forEach(link => {
                link.href = data.youtube_channel || 'https://www.youtube.com/@Aegaming91';
            });
            
            // Set site title if needed
            if (data.site_title) {
                document.title = data.site_title;
                const tournamentTitle = document.querySelector('.tournament-title');
                if (tournamentTitle) {
                    tournamentTitle.textContent = data.site_title;
                }
            }
        })
        .catch(error => {
            console.error('Error fetching site config:', error);
        });
}

// Fetch upcoming matches
function fetchUpcomingMatches() {
    fetch('/api/matches/upcoming')
        .then(response => response.json())
        .then(matches => {
            const upcomingMatchesList = document.getElementById('upcoming-matches-list');
            if (upcomingMatchesList) {
                if (matches.length === 0) {
                    upcomingMatchesList.innerHTML = '<p>No upcoming matches scheduled</p>';
                } else {
                    let html = '<ul class="upcoming-matches-list">';
                    matches.forEach(match => {
                        const matchDate = new Date(match.match_date);
                        html += `
                            <li class="upcoming-match-item">
                                <div class="match-name">${match.name}</div>
                                <div class="match-details">
                                    <span class="match-date">${formatDate(matchDate)}</span>
                                    <span class="match-map">${match.map_name}</span>
                                </div>
                            </li>
                        `;
                    });
                    html += '</ul>';
                    upcomingMatchesList.innerHTML = html;
                }
            }
            
            // Also update the schedule section
            updateMatchSchedule(matches);
        })
        .catch(error => {
            console.error('Error fetching upcoming matches:', error);
            const upcomingMatchesList = document.getElementById('upcoming-matches-list');
            if (upcomingMatchesList) {
                upcomingMatchesList.innerHTML = '<p>Error loading upcoming matches</p>';
            }
        });
}

// Fetch live matches
function fetchLiveMatches() {
    fetch('/api/matches/live')
        .then(response => response.json())
        .then(matches => {
            const currentMatch = document.getElementById('current-match');
            if (currentMatch) {
                if (matches.length === 0) {
                    currentMatch.innerHTML = '<p>No matches currently live</p>';
                } else {
                    const match = matches[0]; // Display the first live match
                    const matchDate = new Date(match.match_date);
                    let html = `
                        <div class="live-match-info">
                            <h4 class="match-name">${match.name}</h4>
                            <div class="match-details">
                                <p><strong>Date:</strong> ${formatDate(matchDate)}</p>
                                <p><strong>Map:</strong> ${match.map_name}</p>
                            </div>
                            <div class="watch-container">
                                <a href="${match.youtube_link || 'https://www.youtube.com/@Aegaming91'}" 
                                   class="btn btn-danger" target="_blank">
                                   Watch Now
                                </a>
                            </div>
                        </div>
                    `;
                    currentMatch.innerHTML = html;
                }
            }
        })
        .catch(error => {
            console.error('Error fetching live matches:', error);
            const currentMatch = document.getElementById('current-match');
            if (currentMatch) {
                currentMatch.innerHTML = '<p>Error loading live match information</p>';
            }
        });
}

// Update match schedule section
function updateMatchSchedule(matches) {
    const matchSchedule = document.getElementById('match-schedule');
    if (matchSchedule) {
        if (!matches || matches.length === 0) {
            matchSchedule.innerHTML = '<p class="text-center">No matches scheduled at this time</p>';
        } else {
            let html = '<div class="schedule-list">';
            matches.forEach(match => {
                const matchDate = new Date(match.match_date);
                html += `
                    <div class="schedule-item">
                        <div class="schedule-date">
                            <div class="date">${matchDate.getDate()}</div>
                            <div class="month">${matchDate.toLocaleString('default', { month: 'short' })}</div>
                        </div>
                        <div class="schedule-details">
                            <h4 class="match-name">${match.name}</h4>
                            <div class="match-info">
                                <span class="match-time">${matchDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                <span class="match-map">${match.map_name}</span>
                                <span class="match-status ${match.status}">${match.status}</span>
                            </div>
                        </div>
                    </div>
                `;
            });
            html += '</div>';
            matchSchedule.innerHTML = html;
        }
    }
}

// Fetch all teams
function fetchTeams() {
    fetch('/api/teams/')
        .then(response => response.json())
        .then(teams => {
            const teamsContainer = document.getElementById('teams-container');
            if (teamsContainer) {
                if (teams.length === 0) {
                    teamsContainer.innerHTML = '<p class="text-center">No teams registered yet</p>';
                } else {
                    let html = '';
                    teams.forEach(team => {
                        html += `
                            <div class="team-card">
                                <div class="team-logo-container">
                                    <img src="${team.logo_path}" alt="${team.name} Logo" class="team-logo">
                                </div>
                                <div class="team-info">
                                    <h3 class="team-name">${team.name}</h3>
                                    <p class="team-captain">Captain: ${team.captain_name}</p>
                                    <p class="team-rank">Rank: ${team.rank || 'N/A'}</p>
                                    <p class="team-points">Points: ${team.total_points || '0'}</p>
                                </div>
                            </div>
                        `;
                    });
                    teamsContainer.innerHTML = html;
                }
            }
        })
        .catch(error => {
            console.error('Error fetching teams:', error);
            const teamsContainer = document.getElementById('teams-container');
            if (teamsContainer) {
                teamsContainer.innerHTML = '<p class="text-center">Error loading teams</p>';
            }
        });
}

// Fetch rankings
function fetchRankings() {
    fetch('/api/rankings/')
        .then(response => response.json())
        .then(teams => {
            const rankingsTableBody = document.getElementById('rankings-table-body');
            if (rankingsTableBody) {
                if (teams.length === 0) {
                    rankingsTableBody.innerHTML = '<tr><td colspan="4" class="text-center">No rankings available</td></tr>';
                } else {
                    let html = '';
                    teams.forEach(team => {
                        html += `
                            <tr>
                                <td>${team.rank || 'N/A'}</td>
                                <td>${team.name}</td>
                                <td><img src="${team.logo_path}" alt="${team.name} Logo" class="team-logo-small"></td>
                                <td>${team.total_points || '0'}</td>
                            </tr>
                        `;
                    });
                    rankingsTableBody.innerHTML = html;
                }
            }
        })
        .catch(error => {
            console.error('Error fetching rankings:', error);
            const rankingsTableBody = document.getElementById('rankings-table-body');
            if (rankingsTableBody) {
                rankingsTableBody.innerHTML = '<tr><td colspan="4" class="text-center">Error loading rankings</td></tr>';
            }
        });
}

// Handle team registration form submission
function handleTeamRegistration(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    
    // Show loading state
    const submitButton = form.querySelector('button[type="submit"]');
    const originalButtonText = submitButton.textContent;
    submitButton.textContent = 'Registering...';
    submitButton.disabled = true;
    
    fetch('/api/teams/register', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert('Error: ' + data.error);
        } else {
            alert('Team registered successfully!');
            form.reset();
            // Refresh teams list
            fetchTeams();
        }
    })
    .catch(error => {
        console.error('Error registering team:', error);
        alert('An error occurred while registering your team. Please try again.');
    })
    .finally(() => {
        // Reset button state
        submitButton.textContent = originalButtonText;
        submitButton.disabled = false;
    });
}

// Helper function to format dates
function formatDate(date) {
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
