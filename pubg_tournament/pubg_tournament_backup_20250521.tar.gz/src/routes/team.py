import os
import uuid
from flask import Blueprint, request, jsonify, current_app
from werkzeug.utils import secure_filename
from src.models import db, Team, Player

team_bp = Blueprint('team', __name__)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@team_bp.route('/register', methods=['POST'])
def register_team():
    if 'logo' not in request.files:
        return jsonify({'error': 'No logo file provided'}), 400
    
    logo_file = request.files['logo']
    
    if logo_file.filename == '':
        return jsonify({'error': 'No logo file selected'}), 400
    
    if not allowed_file(logo_file.filename):
        return jsonify({'error': 'File type not allowed. Please upload PNG, JPG, JPEG, or GIF'}), 400
    
    # Get form data
    data = request.form
    team_name = data.get('name')
    captain_name = data.get('captain_name')
    contact_info = data.get('contact_info')
    
    # Validate required fields
    if not team_name or not captain_name or not contact_info:
        return jsonify({'error': 'Missing required fields'}), 400
    
    # Check if team name already exists
    existing_team = Team.query.filter_by(name=team_name).first()
    if existing_team:
        return jsonify({'error': 'Team name already exists'}), 400
    
    # Save logo file with unique name
    filename = secure_filename(logo_file.filename)
    file_ext = filename.rsplit('.', 1)[1].lower()
    unique_filename = f"{uuid.uuid4().hex}.{file_ext}"
    logo_path = os.path.join('uploads', 'logos', unique_filename)
    full_path = os.path.join(current_app.static_folder, 'uploads', 'logos', unique_filename)
    logo_file.save(full_path)
    
    # Create new team
    new_team = Team(
        name=team_name,
        logo_path=logo_path,
        captain_name=captain_name,
        contact_info=contact_info
    )
    
    # Add players if provided
    players_data = request.form.getlist('players')
    pubg_ids = request.form.getlist('pubg_ids')
    
    if len(players_data) != len(pubg_ids):
        return jsonify({'error': 'Player names and PUBG IDs must match in count'}), 400
    
    try:
        db.session.add(new_team)
        db.session.flush()  # Get the team ID without committing
        
        # Add players
        for i in range(len(players_data)):
            if players_data[i] and pubg_ids[i]:
                player = Player(
                    team_id=new_team.id,
                    name=players_data[i],
                    pubg_id=pubg_ids[i]
                )
                db.session.add(player)
        
        db.session.commit()
        return jsonify({
            'message': 'Team registered successfully',
            'team_id': new_team.id
        }), 201
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@team_bp.route('/', methods=['GET'])
def get_all_teams():
    teams = Team.query.all()
    result = []
    
    for team in teams:
        team_data = {
            'id': team.id,
            'name': team.name,
            'logo_path': team.logo_path,
            'captain_name': team.captain_name,
            'registration_date': team.registration_date,
            'total_points': team.total_points,
            'rank': team.rank,
            'players': []
        }
        
        for player in team.players:
            team_data['players'].append({
                'id': player.id,
                'name': player.name,
                'pubg_id': player.pubg_id
            })
        
        result.append(team_data)
    
    return jsonify(result), 200

@team_bp.route('/<int:team_id>', methods=['GET'])
def get_team(team_id):
    team = Team.query.get_or_404(team_id)
    
    team_data = {
        'id': team.id,
        'name': team.name,
        'logo_path': team.logo_path,
        'captain_name': team.captain_name,
        'contact_info': team.contact_info,
        'registration_date': team.registration_date,
        'total_points': team.total_points,
        'rank': team.rank,
        'players': []
    }
    
    for player in team.players:
        team_data['players'].append({
            'id': player.id,
            'name': player.name,
            'pubg_id': player.pubg_id
        })
    
    return jsonify(team_data), 200
